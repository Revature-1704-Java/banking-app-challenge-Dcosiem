package com.dcosiem.bank;
import java.util.*;
import java.text.NumberFormat;
import java.text.ParsePosition;


public class Bank{

    int currentNumberAccounts = 0;
    private HashMap<Integer, Account> bankDB;
    private HashMap<Integer, Integer> lookupDB; 

    public Bank (HashMap<Integer, Account> bankDB, HashMap<Integer, Integer> lookupDB){
        this.bankDB = bankDB;
        this.lookupDB = lookupDB;
        
    }
    public HashMap<Integer, Account> getBankDB(){
        return this.bankDB;
    }
    public HashMap<Integer, Integer>getLookupDB(){
        return this.lookupDB;
    }
    public int getCurrentNumber(){
        return currentNumberAccounts;
    }

    public boolean verifyPin(Scanner scan, int p){
        System.out.println("Please enter your 4 digit PIN");
        String temp = scan.nextLine();
        int pin = Integer.parseInt(inputValidation(temp, scan));
        return pin == p;

    }



    public int createAccount(Scanner scan, String fName, String lName) {

        System.out.println("Please enter a 4 digit pin for your account.");
        String temp = scan.nextLine();
        if(isNumeric(temp) == true) {
            String validPin = inputValidation(temp, scan);
            int pin = Integer.parseInt(validPin);
            double balance = 0;
            int newAccountNumber = currentNumberAccounts + 1;
            Account newMemeber = new Account(fName, lName, newAccountNumber, balance, pin);
            //add into database and lookupDB
            bankDB.put(pin, newMemeber);
            lookupDB.put(newAccountNumber, pin);
            currentNumberAccounts++;
            System.out.println();
            System.out.println("Account Creation Completed!");
            return pin;
        } else {
            System.out.println("You have entered an invalid PIN. Starting over again.");
            createAccount(scan, fName, lName);
        }
        return 0;
        
    }
    public boolean isNumeric(String str) {
        NumberFormat formatter = NumberFormat.getInstance();
        ParsePosition pos = new ParsePosition(0);
        formatter.parse(str, pos);
        return str.length() == pos.getIndex();
    }

    public String inputValidation(String str, Scanner scan) { 
        
        if (str.length() != 4 || !isNumeric(str)) {
            System.out.println("I'm sorry but that was not a valid PIN, please try again.");
            String strIn = scan.nextLine();
            inputValidation(strIn, scan);
        } 
        return str;
    }
    


}