package com.dcosiem.bank;

public interface AccountInterface {
	public String getName();
	public boolean verifyPin(int pin);
	public void deposit(double amount);
	public void withdraw(double amount);
	public void query();
}
