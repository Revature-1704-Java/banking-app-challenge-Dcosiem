package com.dcosiem.bank;

import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class App {


    public static void main(String[] args) {

       
        //pin => acc
        HashMap<Integer, Account> bankDB = new HashMap<Integer, Account>();

        //accNum => pin
        HashMap<Integer, Integer> lookupDB = new HashMap<Integer, Integer>();
        Bank b = new Bank(bankDB, lookupDB);
        String fileName = "bankdb.txt";
        String line = null;
        int currentAccount;
        

        try {
            FileReader fileReader = new FileReader(fileName);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            //load accounts into DB from file
            while ((line = bufferedReader.readLine()) != null) {
                String[] strArr = line.split(" ");
                int accNum = Integer.parseInt(strArr[2]);
                double balance = Double.parseDouble(strArr[3]);
                int pin = Integer.parseInt(strArr[4]);
                Account acc = new Account(strArr[0], strArr[1], accNum, balance, pin);
                lookupDB.put(accNum, pin);
                bankDB.put(pin, acc);
                b.currentNumberAccounts++;
            }
            // Always close files.
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileName + "'");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        System.out.println("Welcome to the Trustee Bank.");
        System.out.println("Please enter your account number or if this is your first time type New.");
        //Checking DB for accountNumber -> check pin -> let them in
        Scanner scan = new Scanner(System.in);
        String command;

        while (scan.hasNext() == true) {
            command = scan.nextLine();
            int accountNumber = 0;
            if (Parser.isNumeric(command) == true) {
                accountNumber = Integer.parseInt(command);
            }
            
            if (command.equals("New")) {
                System.out.println("Thank you for choosing the Trustee Bank.");
                System.out.println("Please enter your first name.");
                String fName = scan.nextLine();
                System.out.println("Please enter your last name.");
                String lName = scan.nextLine();
                currentAccount = b.createAccount(scan, fName, lName);                
            } else if (lookupDB.containsKey(accountNumber)) {
                int attempts = 0;
                while(!b.verifyPin(scan, lookupDB.get(accountNumber))){
                    if(attempts == 3) {
                        System.out.println("I'm sorry but you have been locked out of the account.");
                        System.out.println("Goodbye!");
                        System.exit(0);
                    }
                    System.out.println("I'm sorry, but thats incorrect. Please try again");
                    attempts++;
                }
                System.out.println("Welcome back " + bankDB.get(lookupDB.get(accountNumber)).getName());
                currentAccount = lookupDB.get(accountNumber);

            } else {
                System.out.println("There was no account with that number found.");
                System.out.println("We will now run you through the setup account program.");
                System.out.println("Thank you for choosing the Trustee Bank.");
                System.out.println("Please enter your first name.");
                String fName = scan.nextLine();
                System.out.println("Please enter your last name.");
                String lName = scan.nextLine();
                currentAccount = b.createAccount(scan, fName, lName);                
            }
            System.out.println("Here is a list of things we can help you with today");
            System.out.println();
            System.out.println("Deposit");
            System.out.println("Withdraw");
            System.out.println("Querry");
            System.out.println("Exit");
            command = scan.nextLine();
            try {
				Parser.parse(command, scan, b, currentAccount);
			} catch (IOException e) {
				e.printStackTrace();
			}
            

        }

        
    }
}
