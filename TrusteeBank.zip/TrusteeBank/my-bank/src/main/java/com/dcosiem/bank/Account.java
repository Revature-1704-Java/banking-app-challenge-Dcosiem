package com.dcosiem.bank;
import java.text.NumberFormat;
import java.text.ParsePosition;

public class Account implements AccountInterface{

	
	private String firstName;
    private String lastName;
    private int accountNum;
    private double balance;
    private int pin;


    public Account(String f, String l, int accountNum, double balance, int pin) {
        this.firstName = f;
        this.lastName = l;
        this.accountNum = accountNum;
        this.balance = balance;
        this.pin = pin;
    }

    public Account(){

    }

    public String getName(){
        return this.firstName + " " + this.lastName;
    }

    public boolean verifyPin(int pin){
        return pin == this.pin;
    }
    public boolean isNumeric(String str) {
        NumberFormat formatter = NumberFormat.getInstance();
        ParsePosition pos = new ParsePosition(0);
        formatter.parse(str, pos);
        return str.length() == pos.getIndex();
    }


    public void deposit(double amount){
        this.balance += amount;        
    }


    public void withdraw(double amount) {
        this.balance -= amount;
    }


    public void query(){
        System.out.println(firstName + " " + lastName);
        System.out.println("Account Number:" + accountNum);
        System.out.println("Balance:" + balance);
    }
    
    public String toString() {
    	return firstName + " " + lastName + " " + accountNum + " " + balance + " " + pin;
    }
    


}