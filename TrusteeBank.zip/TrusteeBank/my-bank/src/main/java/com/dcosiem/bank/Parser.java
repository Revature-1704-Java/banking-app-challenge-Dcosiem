package com.dcosiem.bank;
 import java.util.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.NumberFormat;
 import java.text.ParsePosition;

public class Parser {

    public static boolean isNumeric(String str) {
        NumberFormat formatter = NumberFormat.getInstance();
        ParsePosition pos = new ParsePosition(0);
        formatter.parse(str, pos);
        return str.length() == pos.getIndex();
    }

    public static void parse(String str, Scanner scan, Bank bank, int currentAccount) throws IOException {
        if(str.equals("Deposit")) {
            System.out.println("How much would you like to deposit?");
            String temp = scan.nextLine();
            //With more time. add check for negative amounts 
            if(isNumeric(temp) && Double.parseDouble(temp) > 0) {
                double amount = Double.parseDouble(temp);    
                bank.getBankDB().get(currentAccount).deposit(amount);
            } else {
                System.out.println("Sorry thats not a valid amount, try again");
                parse("Deposit", scan, bank, currentAccount);
            }
            System.out.println("Deposit Successful!");
            
        } else if (str.equals("Withdraw")) {
            System.out.println("How much would you like to withdraw?");
            String temp = scan.nextLine();
            //With more time. add check for negative amounts 
            if(isNumeric(temp) && Double.parseDouble(temp) > 0) {                
                bank.getBankDB().get(currentAccount).withdraw(Double.parseDouble(temp));
            } else {
                System.out.println("Sorry thats not a valid amount, try again");
                parse("Withdraw", scan, bank, currentAccount);
            }
            System.out.println("Withdraw Successful!");
        } else if (str.equals("Query")) {
            bank.getBankDB().get(currentAccount).query();
        } else if (str.equals("Exit")) {
            System.out.println("Goodbye!");
            BufferedWriter out = null;
            PrintWriter pw = new PrintWriter("bankdb.txt");
            pw.close();
            try {
            	FileWriter fstream = new FileWriter("bankdb.txt", true);
            	out = new BufferedWriter(fstream);
			
				for(Account a : bank.getBankDB().values()) {
					out.write(a.toString());
					out.newLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.close();
				}
			}
            //Save database
            System.exit(0);
            //Say goodbye and then save current DB to file and then exit
        } else {
            //Not valid ask them again
            System.out.println("I'm sorry but that is not a valid command. Please try again.");
            String nextCommand = scan.nextLine();
            parse(nextCommand, scan, bank, currentAccount);            
        }
        System.out.println("Thank you for using Trustee Bank.");
        System.out.println();
        System.out.println("Here is a list of things we can help you with today");
        System.out.println();
        System.out.println("Deposit");
        System.out.println("Withdraw");
        System.out.println("Querry");
        System.out.println("Exit");
        String nextCommand = scan.nextLine();
        parse(nextCommand, scan, bank, currentAccount);        
    }
}